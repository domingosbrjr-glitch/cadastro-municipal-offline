const String gatewayBaseUrl = "http://10.0.2.2:9000";
const String cloudBaseUrl = "http://10.0.2.2:8000";
