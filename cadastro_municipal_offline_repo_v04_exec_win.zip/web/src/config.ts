export const API_BASE = "http://localhost:8000";
